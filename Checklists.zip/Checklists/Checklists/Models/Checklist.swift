//
//  Checklist.swift
//  Checklists
//
//  Created by Bane Manojlovic on 16/07/2020.
//  Copyright © 2020 Bane Manojlovic. All rights reserved.
//

import Foundation
import UIKit

class Checklist: NSObject, Codable {
    
    // MARK: - Properties
    var name = ""
    var items = [ChecklistItem]()
    var iconName = "No Icon"
    
    // MARK: - Initialization
    init(name: String, iconName: String = "No Icon") {
        self.name = name
        self.iconName = iconName
        super.init()
    }
    
    // MARK: - Methods
    func countUncheckedItems() -> Int {
        var count = 0
        for item in items where !item.checked {
            count += 1
        }
        return count
    }
}
